# TorchHandy

## Introduction

This is a handy implementation of some useful pytorch modules and functions, such as fully connected layers, etc.

